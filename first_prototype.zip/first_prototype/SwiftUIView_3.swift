//
//  SwiftUIView_3.swift
//  first_prototype
//
//  Created by Turma02-17 on 19/03/25.
//

import SwiftUI

struct SwiftUIView_3: View {
    var body: some View {
        VStack{
                ZStack{
   
                    Image("windowns_xp")

                        .resizable()
                        .frame(width: 200, height: 200)
                        .padding()
                        Text("tamo jogando ou tamo jogando?")
                        .zIndex(1)
                    
                    ZStack{
                        Button("Entrar"){
                        }
                        .zIndex(2)
                    }

                    
                    Spacer()
                    
                    ZStack() {
                        Image("windowns_xp")
                            .opacity(0.8)
                            .zIndex(0)
                }
            }
        }
    }
}

#Preview {
    SwiftUIView_3()
}
