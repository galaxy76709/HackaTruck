//
//  first_prototypeApp.swift
//  first_prototype
//
//  Created by Turma02-17 on 19/03/25.
//

import SwiftUI

@main
struct first_prototypeApp: App { // aqui ele espera algum aquivo visual
    
    var body: some Scene {// penado de fomra igual ao inta, esse e como o "feed" dele 
        WindowGroup {
            ContentView()
        }
    }
}
