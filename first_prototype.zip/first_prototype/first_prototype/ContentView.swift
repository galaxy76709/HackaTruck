//
//  ContentView.swift
//  first_prototype
//
//  Created by Turma02-17 on 19/03/25.
// aqui e como se fosse o html, sem muitas novidades

import SwiftUI

struct ContentView: View {
    var body: some View {
        VStack (){
            HStack (){
                Rectangle()
                    .fill (.red)
                    .frame(width: 100, height: 100)
                    .padding()
                Spacer()
                
                Rectangle()
                    .fill (.blue)
                    .frame(width: /*@START_MENU_TOKEN@*/100/*@END_MENU_TOKEN@*/, height: 100)
                    .padding()
                
            }
            Spacer()
            HStack{
                HStack (){
                    Rectangle()
                        .fill (.green)
                        .frame(width: 100, height: 100)
                        .padding()
                    Spacer()
                    
                    Rectangle()
                        .fill (.yellow)
                        .frame(width: /*@START_MENU_TOKEN@*/100/*@END_MENU_TOKEN@*/, height: 100)
                        .padding()
                
                }
            }
        }
    }
}


 #Preview {// serve para ver a tela do iphone do lado direito
ContentView()
 }
