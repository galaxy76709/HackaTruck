//
//  SwiftUIView.swift
//  first_prototype
//
//  Created by Turma02-17 on 19/03/25.
//

import SwiftUI

struct SwiftUIView: View {
    var body: some View {
        VStack(){
            HStack {
                Image("windowns_xp")
                    .resizable()
                    .scaledToFill()
                    .frame(width: 200, height: 200)
                    .clipShape(/*@START_MENU_TOKEN@*/Circle()/*@END_MENU_TOKEN@*/)
                    .padding()
                VStack{
                    Text("lorem !5")
                        .foregroundStyle(.red)
                    Text("lorem !5")
                        .foregroundStyle(.blue)
                    Text("lorem !5")
                        .foregroundStyle(.green)
                }
            }
        }
    }
}

#Preview {
    SwiftUIView()
}
